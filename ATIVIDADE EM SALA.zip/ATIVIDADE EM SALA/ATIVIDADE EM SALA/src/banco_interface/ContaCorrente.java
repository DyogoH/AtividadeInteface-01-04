package banco_interface;

public class ContaCorrente implements Conta {
    private double saldo;

    @Override
    public double getSaldo() {
        return saldo;
    }

    @Override
    public void deposita(double valor) {
        saldo += valor;
    }

    @Override
    public void retira(double valor) {
        saldo -= valor;
    }

    @Override
    public void atualiza(double taxaSelic) {
        saldo += saldo * taxaSelic;
    }
}
